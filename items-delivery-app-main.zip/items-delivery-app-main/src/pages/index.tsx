import Home from './Home';
import ProductView from './ProductView';
import Error404 from './Error404';

export { Home, ProductView, Error404 };
