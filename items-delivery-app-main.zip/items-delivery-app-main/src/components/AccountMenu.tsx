import React from 'react';

type Props = {};

const AccountMenu = (props: Props) => {
  return <div>AccountMenu</div>;
};

export default AccountMenu;
