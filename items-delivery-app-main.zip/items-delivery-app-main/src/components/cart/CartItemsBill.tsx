import React from 'react';

const CartItemsBill = () => {
  return <div>CartItemsBill</div>;
};

export default CartItemsBill;
